document.getElementById('generate-link').addEventListener('click', async () => {
    try {
        const response = await fetch('http://localhost:3000/generate-link', { method: 'POST' });
        if (response.ok) {
            const { link } = await response.json();
            document.getElementById('secure-link').href = link;
            document.getElementById('secure-link').textContent = link;
            document.getElementById('link-container').classList.remove('hidden');
        } else {
            alert('Failed to generate the link. Please try again.');
        }
    } catch (error) {
        console.error('Error generating link:', error);
        alert('An error occurred. Please try again.');
    }
});