const express = require('express');
const crypto = require('crypto');
const cors = require('cors');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// In-memory storage for links (use a database for production)
const links = {};

// Generate a secure remote access link
app.post('/generate-link', (req, res) => {
    const token = crypto.randomBytes(32).toString('hex');
    const expirationTime = Date.now() + 15 * 60 * 1000; // 15 minutes validity

    const link = `http://localhost:${PORT}/access/${token}`;
    links[token] = { expirationTime };

    res.json({ link });
});

// Validate and handle access link
app.get('/access/:token', (req, res) => {
    const { token } = req.params;
    const linkData = links[token];

    if (!linkData) {
        return res.status(404).send('Invalid or expired link.');
    }

    if (Date.now() > linkData.expirationTime) {
        delete links[token];
        return res.status(410).send('Link has expired.');
    }

    res.send('Access granted. Session will begin now.');
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});